public class Config {

	public static String PATH = "certs";
	public static String EMAIL = "example@example.com";
	public static String DOMAIN = "127.0.0.1";

}
